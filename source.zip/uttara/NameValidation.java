package com.uttara;

public class NameValidation {
	public static boolean validation(String s)
	{
		if((s.length()<3 || s.length()>30))
			return false;
		if(!Character.isAlphabetic(s.charAt(0)))
		return false;
		if(s.split(" ").length>1)
			return false;
		for(int i=1;i<s.length();i++)
		{
			if(!((Character.isAlphabetic(s.charAt(i)) || Character.isDigit(s.charAt(i)))))
			{
				return false;
			}
		}
		return true;
	}
		

}
