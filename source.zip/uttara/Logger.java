package com.uttara;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.Date;

public class Logger {
	private Logger()
	{
		
		
	}
	private static Logger obj=null;
	public static Logger getInstance()
	{
		if(obj==null)
			obj=new Logger();
		return obj;
	}
	public void log(final String s)
	{
		new Thread(new Runnable() {
			
			@Override                               
			public void run() {
				BufferedWriter bw=null;
				try {
					bw=new BufferedWriter(new FileWriter("C:/Users/ADMIN/Desktop/giri1.txt", true));
					Date dt=new Date();
					bw.write(dt.toString()+":"+s);
					bw.newLine();
					bw.flush();
					
				}
				catch (Exception e) {
					e.printStackTrace();
				}
				finally{
					
					if(bw!=null)
					{
						try
						{
							bw.close();
						}
						catch(Exception e)
						{
							
							e.printStackTrace();
						}
					}
				}
				
				
			}
		}).start();
	}


}
