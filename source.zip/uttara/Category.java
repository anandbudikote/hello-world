package com.uttara;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Category {

	public static void main(String[] args)
	 { 
		try{
int ch=0;


//Logger.getInstance().log("entered choices are"+ch);



while(ch!=5 )
{
	System.out.println("press 1 to enter project name");

	System.out.println("press 2 to load project ");

	System.out.println("press 3 to list project ");

	System.out.println("press 4 to search  project ");

	System.out.println("press 5 to exit");



	Scanner sc=new Scanner(System.in);
	Scanner sc1=new Scanner(System.in);
	System.out.println("Enter Choice");
	int ch2=0;
	while(!sc.hasNextInt())
	{
		
		System.out.println("Enter only integer value");
		sc.next();
	}
	ch=sc.nextInt();
	Logger.getInstance().log("entered choice is       "+ch);
	switch(ch){
	case 1:
		System.out.println("press 1 to enter project name");
	String ProjectName=sc1.nextLine();
boolean b=	NameValidation.validation(ProjectName);
	while(!b)
	{
		
		System.out.println("Enter the proper name ");
		ProjectName=sc1.nextLine();
		 b=	NameValidation.validation(ProjectName);
		
	}
	
	boolean b1=CheckIfProjectExist.projectExist(ProjectName);
	while(b1)
	{
		
		System.out.println("project is already exist so please enter new project name");
		ProjectName=sc1.nextLine();
		 b=	NameValidation.validation(ProjectName);
		 
		 while(!b)
			{
				
				System.out.println("Enter the proper name ");
				ProjectName=sc1.nextLine();
				 b=	NameValidation.validation(ProjectName);
				
			}
		 b1=CheckIfProjectExist.projectExist(ProjectName);
		 Logger.getInstance().log("entered project name is       "+ProjectName);
	}
//	BuildFile.BuildFile(ProjectName);
	while(ch2!=6)
	{
		System.out.println("Press 1 to Add a Task");
		System.out.println("Press 2 to Edit a Task");
		System.out.println("Press 3 to Remove a Task");
		System.out.println("Press 4 to List the Tasks");
		System.out.println("Press 5 to Search");
		System.out.println("Press 6 to Go back");
		System.out.println("enter choice");
		while(!sc.hasNextInt())
		{
			
			System.out.println("Enter only integer value");
			sc.next();
		}
		
		ch2=sc.nextInt();
		 Logger.getInstance().log("entered project name is       "+ch2);
		switch(ch2){
		case 1:
			System.out.println("Enter the taskname");
			String TaskName=sc1.nextLine();
			boolean b3=NameValidation.validation(TaskName);
			 while(!b3)
				{
					
					System.out.println("Enter the proper name ");
					TaskName=sc1.nextLine();
					 b3=NameValidation.validation(TaskName);
					
				}
			 
			 Logger.getInstance().log("entered project name is       "+TaskName);
			 System.out.println("enter the description of task");
			String desc= sc1.nextLine();
			 Logger.getInstance().log("entered taskname is       "+desc);
			System.out.println("enter the status ");
			String status=sc1.nextLine();
			 Logger.getInstance().log("entered status is       "+status);
			System.out.println("enter the tags");
			String  tags=sc1.nextLine();
			 Logger.getInstance().log("entered tags is       "+tags);
			System.out.println("enter the end date");
			String dt=sc1.nextLine();
			 Logger.getInstance().log("entered date is       "+dt);
			System.out.println("enter the priority 1> hihg 2>medium 3>low");
			int priority=sc.nextInt();
			 Logger.getInstance().log("entered priority is       "+priority);
			TaskBean bean = new TaskBean( TaskName,  desc,  status,  priority,
					 dt, tags);
			TestModel tm=new TestModel();
			String m =tm.createTask(bean, ProjectName);
			//System.out.println(bean.getTaskName());
			
System.out.println(m);
ch2=0;
			break ;
		case 2:
			while(ch2!=4)
			{
			
			
			System.out.println("enter 1 to edit  status");
			System.out.println("enter 2 to edit priority ");
			System.out.println("enter 3 to edit date");
			while(!sc.hasNextInt())
			{
				
				System.out.println("Enter only integer value");
				sc.next();
			}
		 ch2=sc.nextInt();
			
		 Logger.getInstance().log("entered choice is       "+ch2);
			switch(ch2)
			{
			case 1:
				 System.out.println("enter taskname  to Edit a Task");
					String taskName=sc1.nextLine();
					boolean q=EditStatus.findTask(taskName,  ProjectName);
					while(!q)
					{
						System.out.println("entered taskname not exist please enter the existed taskname ");
						taskName=sc1.nextLine();
						q=EditStatus.findTask(taskName,  ProjectName);
					}
					 Logger.getInstance().log("entered taskname is       "+taskName);
				System.out.println("enter the new status");
				String z=sc1.nextLine();
				
				 Logger.getInstance().log("entered new status is       "+z);
				EditTask.editStatus(taskName, z, ProjectName);
				break;
			case 2:
				 System.out.println("enter taskname  to Edit a Task");
					String taskName1=sc1.nextLine();
					 Logger.getInstance().log("entered taskname is       "+taskName1);
				System.out.println("enter the new Priority");
				String z1=sc1.nextLine();
				 Logger.getInstance().log("entered new priority is       "+z1);
				EditTask.editPriority(taskName1, z1, ProjectName);
				break;
			case 3:
				 System.out.println("enter taskname  to Edit a Task");
					String taskName2=sc1.nextLine();
					 Logger.getInstance().log("entered taskname is       "+taskName2);
				System.out.println("enter the new Date");
				String z2=sc1.nextLine();
				 Logger.getInstance().log("entered new date is       "+z2);
				EditTask.editDate(taskName2, z2, ProjectName);
				break;
			}
			}
			break;
		case 3:
			System.out.println("enter taskname  to Remove a Task");
			String name=sc1.nextLine();
			 Logger.getInstance().log("entered  taskname is       "+name);
			EditClass.removeTask(name,ProjectName);
			break;
		case 4:
			//System.out.println("Press 4 to List the Tasks");
			TestModel tm1=new TestModel();
			List<TaskBean> beans =tm1.getTasks(ProjectName);										//List<TaskBean> beans = model.getTasks(catName);
			for(TaskBean b12 : beans)
			{
System.out.println("Name : "+b12.getTaskName()+" Desc : "+b12.getDesc()+" End Dt : "+b12.getDt()+" Priority : "+b12.getPriority()+" Status : "+b12.getStatus()+" Tags : "+b12.getTags() );

			}
			break;
		case 5:
			System.out.println("enter the task name to search");
			String taskname=sc1.nextLine();
			 Logger.getInstance().log("entered taskname is       "+taskname);
			TaskBean tb=SearchTask.getTask(ProjectName, taskname);
			System.out.println("Name : "+tb.getTaskName()+" Desc : "+tb.getDesc()+" End Dt : "+tb.getDt()+" Priority : "+tb.getPriority()+" Status : "+tb.getStatus()+" Tags : "+tb.getTags() );

		
			break;
		
			
		}
		
	
	}
	break;
	case 2:
		System.out.println("Enter the projectName ");
		String proj=sc1.nextLine();
		 Logger.getInstance().log("entered project name is       "+proj);
		boolean b3=CheckIfProjectExist.projectExist(proj);
		if(b3==true){
		
		System.out.println("Project exist");
		}else
		{
		
		System.out.println("Project not exist");
		}
		
		break;
	case 3:
		//System.out.println("press 3 to list project ");

		ArrayList<File> al=ListClass.main();
		for(File f:al)
	{
		System.out.println(f.getName());
	}
		break;
	case 4:
		System.out.println("Enter the  projectName ");
		String w=sc1.nextLine();
		 Logger.getInstance().log("entered project name is       "+w);
		List<TaskBean> beans=FindProject.getProject(w);	 										//List<TaskBean> beans = model.getTasks(catName);
		for(TaskBean b12 : beans)
		{
System.out.println("Name : "+b12.getTaskName()+" Desc : "+b12.getDesc()+" End Dt : "+b12.getDt()+" Priority : "+b12.getPriority()+" Status : "+b12.getStatus()+" Tags : "+b12.getTags() );

		}
		break;
	

	
		
		
	}
	
}
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		}
	 }

	
	 

