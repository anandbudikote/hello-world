package com.uttara;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class EditTask {
	public static void editStatus(String s4,String q1,String proj)
	{
		
		List<String> al=new ArrayList<String>();
		try {
			BufferedReader br=new BufferedReader(new FileReader("C:\\Users\\Anand v\\Desktop"+proj+".txt"));
		
			String s=null;
			
			Scanner sc=new Scanner(System.in);
		while ((s=br.readLine())!=null)
		{String[] s5=s.split(":");
			for(String s3:s5)
			{
				al.add(s3);
			}
			
		
			}
		//System.out.println(al);
	int q=al.indexOf(s4);
	
	al.set(q+4, q1);
	int c=0;
	BufferedWriter bw=new BufferedWriter(new FileWriter("C:\\Users\\Anand v\\Desktop\\"+proj+".txt"));
	for(String w:al)
	{
	
		

	
	bw.write(w+":");
	++c;
	if(c==6)
	{
		bw.newLine();
		c=0;
	}
	
	}
br.close();
bw.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			
			
		
		}
		
	}
	public static void editPriority(String s4,String q1,String proj)
	{
		
		List<String> al=new ArrayList<String>();
		try {
			BufferedReader br=new BufferedReader(new FileReader("C:\\Users\\Anand v\\Desktop\\"+proj+".txt"));
		
			String s=null;
			
			Scanner sc=new Scanner(System.in);
		while ((s=br.readLine())!=null)
		{String[] s5=s.split(":");
			for(String s3:s5)
			{
				al.add(s3);
			}
			
		
			}
		//System.out.println(al);
	int q=al.indexOf(s4);
	
	al.set(q+3, q1);
	int c=0;
	BufferedWriter bw=new BufferedWriter(new FileWriter("C:\\Users\\Anand v\\Desktop\\"+proj+".txt"));
	for(String w:al)
	{
	
		

	
	bw.write(w+":");
	++c;
	if(c==6)
	{
		bw.newLine();
		c=0;
	}
	
	}
br.close();
bw.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			
			
		
		}
		
	}
	public static void editDate(String s4,String q1,String proj)
	{
		
		List<String> al=new ArrayList<String>();
		try {
			BufferedReader br=new BufferedReader(new FileReader("C:\\Users\\Anand v\\Desktop\\"+proj+".txt"));
		
			String s=null;
			
			Scanner sc=new Scanner(System.in);
		while ((s=br.readLine())!=null)
		{String[] s5=s.split(":");
			for(String s3:s5)
			{
				al.add(s3);
			}
			
		
			}
		//System.out.println(al);
	int q=al.indexOf(s4);
	
	al.set(q+2, q1);
	int c=0;
	BufferedWriter bw=new BufferedWriter(new FileWriter("C:\\Users\\Anand v\\Desktop\\"+proj+".txt"));
	for(String w:al)
	{
	
		

	
	bw.write(w+":");
	++c;
	if(c==6)
	{
		bw.newLine();
		c=0;
	}
	
	}
br.close();
bw.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			
			
		
		}
		
	}
	
}
