package com.uttara;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FindProject {
	public static List<TaskBean> getProject(String ProjectName)
	{
		List<TaskBean> beans = new ArrayList<TaskBean>();
		TaskBean beanie = null;
		
		BufferedReader br = null;
		try
		{
			String line;
			br = new BufferedReader(new FileReader("C:\\Users\\ADMIN\\Desktop\\project\\"+ProjectName+".txt"));
			while((line = br.readLine())!=null)
	
			{
				beanie = new TaskBean();
				String[] sa = line.split(":");
				beanie.setTaskName(sa[0]);
				beanie.setDesc(sa[1]);
				beanie.setDt(sa[2]);
				beanie.setPriority(Integer.parseInt(sa[3]));
				beanie.setStatus(sa[4]);
				beanie.setTags(sa[5]);
				
				beans.add(beanie);
			
			}
			
			
			return beans;
			
		}
		catch(IOException e)
		{
			e.printStackTrace();
			return null;
		}
		finally
		{
			if(br!=null)
				try {
					br.close();
				} catch (IOException e) {
				
					e.printStackTrace();
				}
		}
	}



}
