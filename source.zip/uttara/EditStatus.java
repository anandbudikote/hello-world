package com.uttara;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class EditStatus {
	public static boolean findTask(String s4,String proj)
	{
		
		List<String> al=new ArrayList<String>();
		try {
			BufferedReader br=new BufferedReader(new FileReader("C:\\Users\\Anand v\\Desktop\\"+proj+".txt"));
		
			String s=null;
			
			Scanner sc=new Scanner(System.in);
		while ((s=br.readLine())!=null)
		{String[] s5=s.split(":");
			for(String s3:s5)
			{
				al.add(s3);
			}
			
		
			}
		//System.out.println(al);
	int q=al.indexOf(s4);
	if(q==-1)
	{
		return false;
		
	}
	
br.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			
			
		
		}
		return true;
		
	}
}
