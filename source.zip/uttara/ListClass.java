package com.uttara;

import java.io.File;
import java.util.ArrayList;

public class ListClass {
	public static ArrayList main() {
		File f1=new File("C:\\Users\\ADMIN\\Desktop\\project");
		
ArrayList<File> al=new ArrayList<File>();
File[] fa = f1.listFiles();


for(File f : fa)
{
	al.add(f);
	
	
	
}
return al;


	}


}
