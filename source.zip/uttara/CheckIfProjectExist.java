package com.uttara;

import java.io.File;

public class CheckIfProjectExist {
	public static boolean projectExist(String name)
	{
		String path="C:\\Users\\Anand v\\Desktop\\"+name+".txt";
		
		File f=new File(path);
	if(	f.exists())
	return true;
	return false;
	}

}
