package com.uttara;

public class TaskBean {
	@Override
	public boolean equals(Object arg0) {
		// TODO Auto-generated method stub
		return super.equals(arg0);
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	public TaskBean()
	{
		
	}
	public String getTags() {
		return tags;
	}
	public void setTags(String tags) {
		this.tags = tags;
	}
	public String getTaskName() {
		return TaskName;
	}
	public void setTaskName(String TaskName) {
	this.TaskName = TaskName;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public String getDt() {
		return dt;
	}
	public void setDt(String dt) {
		this.dt = dt;
	}
	private String  TaskName;
	private String  desc;
	private String Status;
	private String tags;
	private int priority;
	private String dt;
	public TaskBean(String TaskName, String desc, String status, int priority,
			String dt,String tags) {
		super();
		this.TaskName = TaskName;
		this.desc = desc;
		this.Status = status;
		this.priority = priority;
		this.dt = dt;
		this.tags=tags;
	}
	
}
