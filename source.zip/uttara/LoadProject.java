package com.uttara;

import java.io.File;
import java.util.Scanner;

public class LoadProject {
	public static String ProjectExist(String n)
	{
		File f=new File("C:\\Users\\ADMIN\\Desktop\\project\\"+n+".txt");
		if(f.exists())
		return "File exist";
		return "File not exist";
		
	}
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the projectname");
		String s=sc.nextLine();
		String q=LoadProject.ProjectExist(s);
		System.out.println(q);
	}

}
