package com.uttara;

import java.io.BufferedWriter;
import java.io.FileWriter;

public class BuildFile {
	public static void BuildFile(String n)
	{
	BufferedWriter bw=null;
	
	try {
		bw=new BufferedWriter(new FileWriter("C:\\Users\\Anand v\\Desktop\\"+n+".txt", true));
		bw.write("huchcha....");
		bw.flush();
		System.out.println();
	} catch (Exception e) {
		e.printStackTrace();
	}
finally{

if(bw!=null)
	try {
		bw.close();
	} catch (Exception e2) {
		e2.printStackTrace();
	}
}
}

}



