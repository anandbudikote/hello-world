package com.uttara;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SearchTask {
	public static TaskBean getTask(String ProjectName,String Taskname)
	{
		
		TaskBean beanie = null;
		
		BufferedReader br = null;
		try
		{
			String line;
			br = new BufferedReader(new FileReader("C:\\Users\\ADMIN\\Desktop\\project\\"+ProjectName+".txt"));
			while((line = br.readLine())!=null)
	
			{
				if(line.startsWith(Taskname))
				{
				beanie = new TaskBean();
				String[] sa = line.split(":");
				beanie.setTaskName(sa[0]);
				beanie.setDesc(sa[1]);
				beanie.setDt(sa[2]);
				beanie.setPriority(Integer.parseInt(sa[3]));
				beanie.setStatus(sa[4]);
				beanie.setTags(sa[5]);
				
				//beans.add(beanie);
			}
			}
			
			//Collections.sort(beans);
			return beanie;
			
		}
		catch(IOException e)
		{
			e.printStackTrace();
			return null;
		}
		finally
		{
			if(br!=null)
				try {
					br.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}

}
